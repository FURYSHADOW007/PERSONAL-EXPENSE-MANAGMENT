# streamlit_app.py placeholder
import streamlit as st
st.title("Budget Tracker")
st.write("App is ready for deployment.")
